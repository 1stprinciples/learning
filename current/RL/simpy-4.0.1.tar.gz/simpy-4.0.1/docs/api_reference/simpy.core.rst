==========================================
``simpy.core`` --- SimPy's core components
==========================================

.. automodule:: simpy.core

.. autoclass:: Environment
    :members:

.. autoclass:: BoundClass
    :members:

.. autoclass:: EmptySchedule

.. autodata:: Infinity
