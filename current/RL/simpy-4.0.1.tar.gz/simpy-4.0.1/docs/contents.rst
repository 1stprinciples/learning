.. _contents:

=======================
Documentation for SimPy
=======================

.. only:: html

    Contents:

.. toctree::
   :maxdepth: 2

   index
   simpy_intro/index
   topical_guides/index
   examples/index
   api_reference/index
   about/index


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
