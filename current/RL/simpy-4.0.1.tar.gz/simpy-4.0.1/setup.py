# encoding: utf-8
from setuptools import setup

setup(use_scm_version=True)
